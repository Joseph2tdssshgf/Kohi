import express from 'express';
import fetch from 'node-fetch';
const app = express();
const PORT = 3000;

const apiKey = 'AIzaSyAMJYTsuaoLP7J4j2P5pWZ5c-Qmm6Aa60k'; // Gemini API Key

app.use(express.json());
app.use(express.static('public'));

app.post('/chat', async (req, res) => {
    try {
        const userText = req.body.text;
        const response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-goog-api-key": apiKey
            },
            body: JSON.stringify({ contents: [{ parts: [{ text: userText }] }] })
        });
        const data = await response.json();
        const botText = data?.candidates?.[0]?.content?.[0]?.text || "Sorry, I couldn't understand that.";
        res.json({ botText });
    } catch (err) {
        console.error(err);
        res.json({ botText: "Error calling AI API." });
    }
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));